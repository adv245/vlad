# Testet Ananlog

https://testnet.analog.one/#/quests

Не забываем ставить звездочки проекту

Другие тестнеты можно найти в моей телеграмм группе https://t.me/+MD-wGMhgdSg1MDk6

## SDK

See [readme](https://github.com/madest92/analog-testnet/tree/main/sdk)

## GMP

See [readme](https://github.com/madest92/analog-testnet/tree/main/gmp)
